/** Automatically generated file. DO NOT MODIFY */
package com.idcardtest.otg;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}